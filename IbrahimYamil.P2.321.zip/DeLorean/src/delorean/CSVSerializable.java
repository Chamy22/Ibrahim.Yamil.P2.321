
package delorean;


public interface CSVSerializable {
    String toCSV();
    
}
