
package delorean;

import java.io.Serializable;

public class ModificacionDeLorean implements Serializable, CSVSerializable, Comparable<ModificacionDeLorean> {
    private static final long serialVersionUID = 1L;

    private int id;
    private String nombre;
    private String responsable;
    private TipoModificacion tipo;

    public ModificacionDeLorean(int id, String nombre, String responsable, TipoModificacion tipo) {
        this.id = id;
        this.nombre = nombre;
        this.responsable = responsable;
        this.tipo = tipo;
    }

    public int getId() { return id; }
    public String getNombre() { return nombre; }
    public String getResponsable() { return responsable; }
    public TipoModificacion getTipo() { return tipo; }

    @Override
    public int compareTo(ModificacionDeLorean o) {
        return Integer.compare(this.id, o.id); 
    }

    @Override
    public String toCSV() {
        return id + "," + nombre + "," + responsable + "," + tipo.name();
    }

    public static ModificacionDeLorean fromCSV(String linea) {
        String[] parts = linea.split(",", 4);
        int id = Integer.parseInt(parts[0].trim());
        String nombre = parts[1].trim();
        String responsable = parts[2].trim();
        TipoModificacion tipo = TipoModificacion.valueOf(parts[3].trim());
        return new ModificacionDeLorean(id, nombre, responsable, tipo);
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(System.lineSeparator());
        sb.append("- id = ").append(id);
        sb.append(System.lineSeparator());
        sb.append("- nombre = ").append(nombre);
        sb.append(System.lineSeparator());
        sb.append("- responsable = ").append(responsable);
        sb.append(System.lineSeparator());
        sb.append("- tipo = ").append(tipo);
        
        return sb.toString();
    }
    

}
