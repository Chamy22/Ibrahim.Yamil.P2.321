package delorean;

import java.io.*;
import java.util.*;
import java.util.function.Consumer;
import java.util.function.Predicate;

public class InventarioDeModificaciones<T extends Serializable & CSVSerializable & Comparable<? super T>> implements Serializable {

    private static final long serialVersionUID = 1L;
    private final List<T> elementos = new ArrayList<>();

    public void agregar(T elem) {
        elementos.add(elem);
    }

    public T obtener(int indice) {
        return elementos.get(indice);
    }

    public T eliminar(int indice) {
        return elementos.remove(indice);
    }

    public void paraCadaElemento(Consumer<T> accion) {
        elementos.forEach(accion);
    }

    public List<T> filtrar(Predicate<T> criterio) {
        List<T> resultado = new ArrayList<>();
        for (T e : elementos) {
            if (criterio.test(e)) {
                resultado.add(e);
            }
        }
        return resultado;
    }

    public void ordenarNatural() {
        Collections.sort(elementos);
    }

    public void ordenar(Comparator<? super T> comp) {
        elementos.sort(comp);
    }

    public void guardarEnArchivo(String ruta) throws IOException {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(ruta))) {
            oos.writeObject(elementos);
        }
    }

    public void cargarDesdeArchivo(String ruta) throws IOException, ClassNotFoundException {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(ruta))) {
            Object obj = ois.readObject();
            elementos.clear();
            elementos.addAll((List<T>) obj);
        }
    }

    public void guardarEnCSV(String ruta) throws IOException {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(ruta))) {
            for (T e : elementos) {
                bw.write(e.toCSV());
                bw.newLine();
            }
        }
    }

    public void cargarDesdeCSV(String ruta) throws IOException {
        elementos.clear();
        File archivo = new File(ruta);

        if (!archivo.exists()) {
            System.out.println("El archivo CSV no existe.");
            return;
        }

        FileReader fr = new FileReader(archivo);
        BufferedReader br = new BufferedReader(fr);

        String linea;
        while ((linea = br.readLine()) != null) {
            if (!linea.trim().isEmpty()) {
                elementos.add((T) ModificacionDeLorean.fromCSV(linea));
            }
        }

        br.close();
        fr.close();
    }

}
